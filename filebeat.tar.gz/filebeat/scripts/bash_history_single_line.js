function process(event) {
    var msg = event.Get("message");
    var re = /^#(\d+)\s+(.*)$/;
    var m = msg.match(re);

    if (m) {
        var ts = parseInt(m[1], 10) * 1000;
        var dt = new Date(ts);
        //var dt = mt.toISOString().replace("T", " ").replace("Z", "");

        var yyyy = dt.getFullYear();
        var MM   = ("0" + (dt.getMonth() + 1)).slice(-2);
        var dd   = ("0" + dt.getDate()).slice(-2);
        var hh   = ("0" + dt.getHours()).slice(-2);
        var mm   = ("0" + dt.getMinutes()).slice(-2);
        var ss   = ("0" + dt.getSeconds()).slice(-2);

        var formatted = yyyy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss
                        + " " + m[2];

        event.Put("message", formatted);
    }

    return event;
}
