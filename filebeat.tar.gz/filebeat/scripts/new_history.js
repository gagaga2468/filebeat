function process(event) {
  var msg = event.Get("message");
  if (!msg) return event;

  // 允许两种形式： "#12345678 rest..." 或 "#12345678\nrest..."
  // 先把换行替成空格（若有）
  var single = msg.replace(/\r?\n/g, " ").trim();

  // 匹配 "#<digits> <command...>"
  var m = single.match(/^#(\d+)\s+(.*)$/);
  if (!m) {
    // 没匹配到就不修改
    return event;
  }

  var tsSec = parseInt(m[1], 10);
  if (isNaN(tsSec)) return event;

  // 转为毫秒并构造 Date（UTC）
  var dt = new Date(tsSec * 1000);

  // YYYY-MM-DD HH:mm:ss (UTC)
  function pad(n){ return (n<10? "0":"") + n; }
  var yyyy = dt.getUTCFullYear();
  var MM   = pad(dt.getUTCMonth() + 1);
  var dd   = pad(dt.getUTCDate());
  var hh   = pad(dt.getUTCHours());
  var mm   = pad(dt.getUTCMinutes());
  var ss   = pad(dt.getUTCSeconds());

  var formatted = yyyy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss;

  // 用格式化时间 + 原命令替换 message 字段
  event.Put("message", formatted + " " + m[2]);

  // 可选：保留原始 timestamp 字段
  event.Put("history_timestamp", tsSec);

  return event;
}

